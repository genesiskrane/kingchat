<template>
  <div id="auth" class="h-screen">
    <router-view></router-view>
  </div>
</template>
