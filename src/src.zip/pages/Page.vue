<template>
  <div id="page" class="w-full min-h-screen bg-black">
    <div class="flex flex-col">
      <div id="cover" class="w-full h-40 bg-green-300 text-center">Cover</div>
      <div id="profile">
        <div id="display-picture" class="border-4 border-white">
          <v-img :src="profile.photoURL" class="w-8 h-8"></v-img>
        </div>
      </div>
      <div id="posts"></div>
    </div>
  </div>
</template>

<script setup>
import { useRoute } from 'vue-router';
import { useAppStore } from '../stores';

const store = useAppStore();
const route = useRoute();
const username = route.params.username;

const data = await store.getUserPage(username);
console.log(data);
const { profile } = data;
delete data.profile;
const page = data;
</script>
