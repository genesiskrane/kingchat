<template>
    <div>Communities Page</div>
</template>