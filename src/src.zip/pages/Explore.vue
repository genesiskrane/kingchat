<template>
    <div>Explore Page</div>
</template>