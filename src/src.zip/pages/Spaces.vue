<template>
    <div>Spaces Page</div>
</template>