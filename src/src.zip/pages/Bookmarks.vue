<template>
  <div>Bookmarks Page</div>
</template>
