<template>
  <div>Notifications Page</div>
</template>
