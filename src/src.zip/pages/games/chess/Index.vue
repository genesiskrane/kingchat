<template>
  <div id="chess">Chess Game</div>
</template>
