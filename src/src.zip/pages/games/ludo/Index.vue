<template>
    <div id="ludo">
Ludo Game
    </div>
</template>