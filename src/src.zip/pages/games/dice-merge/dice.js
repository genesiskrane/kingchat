// sides.set('1', {
//   color: '#ffffff',
//   nodeColor: 'red',
//   cubeRotation: [-0.2, 0, 0],
//   position: [0, 50, 0],
//   cameraPosition: [0, 70, 0],
//   rotate: [-1.51208, 0, 0],
//   positions: [[0, 0, 0]]
// })
// sides.set('2', {
//   color: '#fd2f2c',
//   nodeColor: '#ffffff',
//   cubeRotation: [-0.2, 0, 0],
//   position: [0, 0, 50],
//   cameraPosition: [0, 0, 70],
//   rotate: [0, 0, 0],
//   positions: [
//     [20, 20, 0],
//     [-20, -20, 0]
//   ]
// })
// sides.set('3', {
//   color: '#1056fa',
//   position: [-50, 0, 0],
//   cubeRotation: [0, 0, -0.2],
//   cameraPosition: [-70, 0, 0],
//   rotate: [0, -1.51208, 0],
//   positions: [
//     [20, -20, 0],
//     [0, 0, 0],
//     [-20, 20, 0]
//   ]
// })
// sides.set('4', {
//   color: '#b900fe',
//   position: [50, 0, 0],
//   cubeRotation: [0, 0, 0.2],
//   cameraPosition: [70, 0, 0],
//   rotate: [0, 1.51208, 0],
//   positions: [
//     [20, 20, 0],
//     [20, -20, 0],
//     [-20, 20, 0],
//     [-20, -20, 0]
//   ]
// })
// sides.set('5', {
//   color: '#fe90fe',
//   position: [0, 0, -50],
//   cubeRotation: [0.2, 0, 0],
//   cameraPosition: [0, 0, -70],
//   rotate: [3.02416, 0, 0],
//   positions: [
//     [20, 20, 0],
//     [20, -20, 0],
//     [0, 0, 0],
//     [-20, 20, 0],
//     [-20, -20, 0]
//   ]
// })
// sides.set('6', {
//   color: '#f78901',
//   position: [0, -50, 0],
//   cubeRotation: [-0.2, 0, 0],
//   cameraPosition: [0, -70, 0],
//   rotate: [1.51208, 0, 0],
//   positions: [
//     [20, 20, 0],
//     [20, -20, 0],
//     [0, 20, 0],
//     [0, -20, 0],
//     [-20, 20, 0],
//     [-20, -20, 0]
//   ]
// })
