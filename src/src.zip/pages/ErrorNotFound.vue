<template>
  <div>Error 404 <br />page not found</div>
</template>
