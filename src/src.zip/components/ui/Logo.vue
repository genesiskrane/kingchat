<template>
  <div class="p-2 bg-blue-500 ">
    <img src="../../assets/img/icon-white.svg" class="w-20 h-20 mx-auto rounded-2x" />
  </div>
</template>
